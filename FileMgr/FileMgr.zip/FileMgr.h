#ifndef FILEMGR_H
#define FILEMGR_H
/////////////////////////////////////////////////////////////////////
// FileMgr.h - find files matching specified patterns              //
//             on a specified path                                 //
// ver 2.0                                                         //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2016       //
/////////////////////////////////////////////////////////////////////
/*
* ver 2.0 : 12 Mar 2016
* - fixes bug in directory recursion in find(path)
* - reduces scope of for loop in find for efficiency
* ver 1.0 : 11 Mar 2016
* - first release
*/

#include "IFileMgr.h"
#include "../FileSystem/FileSystem.h"

namespace FileManager
{
  class FileMgr : public IFileMgr
  {
  public:
    using patterns = std::vector<std::string>;
    using File = std::string;
    using Dir = std::string;
    using fileSubscribers = std::vector<IFileEventHandler*>;
    using dirSubscribers = std::vector<IDirEventHandler*>;
    using doneSubscribers = std::vector<IDoneEventHandler*>;

    //----< set default file pattern >-------------------------------

    FileMgr(const std::string& path) : path_(path)
    {
      patterns_.push_back("*.*");
      pInstance_ = this;
    }
    //----< return instance of FileMgr >-----------------------------

    static IFileMgr* getInstance()
    {
      return pInstance_;
    }
    //----< add file pattern, removing default on first call >-------

    void addPattern(const std::string& patt)
    {
      if (patterns_.size() == 1 && patterns_[0] == "*.*")
        patterns_.pop_back();
      patterns_.push_back(patt);
    }
    //----< applications can overload this or reg for fileEvt >------

    virtual void file(const File& f)
    {
      ++numFilesProcessed;
      for (auto pEvtHandler : fileSubscribers_)
      {
        pEvtHandler->execute(f);
      }
    }
    //----< applications can overload this or reg for dirEvt >-------

    virtual void dir(const Dir& fpath)
    {
      for (auto pEvtHandler : dirSubscribers_)
      {
        pEvtHandler->execute(fpath);
      }
    }
    //----< applications can overload this or reg for doneEvt >------

    virtual void done()
    {
      for (auto pEvtHandler : doneSubscribers_)
      {
        pEvtHandler->execute(numFilesProcessed);
      }
    }
    //----< start search on previously specified path >--------------

    void search()
    {
      find(path_);
      done();
    //  for (auto pDoneHandler : doneSubscribers_)
    //  {
    //    pDoneHandler->execute(numFilesProcessed);
    //  }
    }

    void find(const std::string& path)
    {
      std::string fpath = FileSystem::Path::getFullFileSpec(path);
      dir(fpath);
      //for (auto pEvtHandler : dirSubscribers_)
      //{
      //  pEvtHandler->execute(fpath);
      //}
      for (auto patt : patterns_)
      {
        std::vector<std::string> files = FileSystem::Directory::getFiles(fpath, patt);
        for (auto f : files)
        {
          file(f);
          //++numFilesProcessed;
          //for (auto pEvtHandler : fileSubscribers_)
          //{
          //  pEvtHandler->execute(f);
          //}
        }
      }
      std::vector<std::string> dirs = FileSystem::Directory::getDirectories(fpath);
      for (auto d : dirs)
      {
        if (d == "." || d == "..")
          continue;
        std::string dpath = fpath + "\\" + d;
        find(dpath);
      }
    }

    void regForFiles(IFileEventHandler* pHandler)
    {
      fileSubscribers_.push_back(pHandler);
    }

    void regForDirs(IDirEventHandler* pHandler)
    {
      dirSubscribers_.push_back(pHandler);
    }

    void regForDone(IDoneEventHandler* pHandler)
    {
      doneSubscribers_.push_back(pHandler);
    }
  private:
    std::string path_;
    patterns patterns_;
    size_t numFilesProcessed = 0;
    fileSubscribers fileSubscribers_;
    dirSubscribers dirSubscribers_;
    doneSubscribers doneSubscribers_;
    static IFileMgr* pInstance_;
  };

  inline IFileMgr* FileMgrFactory::create(const std::string& path)
  {
    return new FileMgr(path);
  }
}
#endif
